import discord
import random
import asyncio
import os
import json
from discord.ext import commands, tasks
from discord.utils import get
from discord.ext.commands import has_permissions
from random import choice

class Roulette(commands.Cog):

     def __init__(self, client):
           self.client = client

     @commands.command(aliases=["rr", "gun"])
     @commands.has_role('Gunner')
     @commands.cooldown(1, 7, commands.BucketType.user)
     async def shoot(self, ctx, member: discord.Member):
         gunner = ctx.message.author
         role = get(member.guild.roles, name="Alive")     
         gunnerrole =  get(member.guild.roles, name="Gunner")
         botrole = get(member.guild.roles, name="Bots") 
         if gunnerrole in member.roles:
             gunner = ctx.message.author
             role = get(member.guild.roles, name="Alive")     
             gunnerrole =  get(member.guild.roles, name="Gunner") 
             responses = ["click", "click", "click", "click", "click", "BANG"]
             clicks = ["click", "clicc, haha gun go clicc", "click, wtf is this gun broken?", "click, thank all mighty of the holy gods", "click, that was close"]
             random_response = random.choice(responses)
             random_clicks = random.choice(clicks) 
             await ctx.send("You're taking a big risk doing this man.")
             if random_response == "BANG":
                 print ("they dead")
                 message = await ctx.send("SHOOTING...")
                 await asyncio.sleep(2)
                 await message.edit(content = "\nBANG! You're dead. gg")
                 await member.remove_roles(role)
                 await member.remove_roles(gunnerrole)
                 await ctx.send("welp, the gunners dead")
                 return
             else:
                 print ("they not dead")
                 message = await ctx.send("SHOOTING...")
                 await asyncio.sleep(2)
                 await message.edit(content = f"\n{random_clicks}")
                 await ctx.send("Now try to shoot someone else that isnt yourself or the previous gunner.")
                 return
         if botrole in member.roles:
             await ctx.send("Don't try to shoot a bot!")
             return

         if role in member.roles:
             gunner = ctx.message.author
             role = get(member.guild.roles, name="Alive")     
             gunnerrole =  get(member.guild.roles, name="Gunner")
             botrole = get(member.guild.roles, name="bot") 
             responses = ["click", "click", "click", "click", "click", "BANG"]
             clicks = ["click", "clicc, haha gun go clicc", "click, wtf is this gun broken?", "click, thank all mighty of the holy gods", "click, that was close"]
             random_response = random.choice(responses)
             random_clicks = random.choice(clicks)
             if random_response == "BANG":
                 print ("they dead")
                 message = await ctx.send("SHOOTING...")
                 await asyncio.sleep(2)
                 await message.edit(content = "\nBANG! You're dead. gg")
                 await member.remove_roles(role)
                 await ctx.send("gunner, shoot anyone you want again")
             else:
                 print ("they not dead")
                 message = await ctx.send("SHOOTING...")
                 await asyncio.sleep(2)
                 await message.edit(content = f"\n{random_clicks}")
                 await gunner.remove_roles(gunnerrole)
                 await member.add_roles(gunnerrole)
                 await ctx.send("New gunner, shoot anyone you want except for the previous gunner. unless it's the final two")

         else:
             await ctx.send("You can't shoot someone thats already dead.")

     @commands.command()
     async def joingame(self, ctx):
         with open("gameuser.json") as f:
             database = json.load(f)

         if str(ctx.author.id) in database:
             await ctx.send("You've already entered!")
         else:
             with open("gameuser.json") as f:
                 olddatabase = json.load(f)

             data = [str(ctx.author.id)]

             data = olddatabase + data 

             with open("gameuser.json", "w") as file:
                 json.dump(data, file, indent=4, sort_keys=True)
             member = ctx.message.author
             role = get(member.guild.roles, name="Alive")
             await member.add_roles(role)
             await ctx.send("Joined Game!")

     @commands.command()
     @has_permissions(manage_roles=True)
     async def giverole(self, ctx, member: discord.Member):
         role = get(member.guild.roles, name="Gunner")
         await member.add_roles(role)
         await ctx.send("ROLE SENT")

     @commands.command()
     @has_permissions(manage_roles=True)
     async def takerole(self, ctx, member: discord.Member):
         role = get(member.guild.roles, name="Gunner")
         await member.remove_roles(role)
         await ctx.send("ROLE TAKEN")

     @commands.command(aliases=["spin", "wheel"])
     async def random(self, ctx):
         r=random.randint(1,15)
         await ctx.send(f"I'll pick... " + str(r))

def setup(client):
     client.add_cog(Roulette(client))
     print('Russian Roulette has loaded')
