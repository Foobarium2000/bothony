import discord
import random
import asyncio
import os
import json
import re
from discord.ext import commands

class Suggestion(commands.Cog):
     def __init__(self, client):
           self.client =  client


     with open("data.json") as f:
         suggestions = json.load(f)

     @commands.command()
     async def suggest(self, ctx, suggestions: str, *, description):

         if not description:
             await ctx.send("I need a description to go with the command suggestion")
             return         

         suggestions = [str(suggestions),
                        str(description)]         
         
         with open("data.json") as f:
             oldsuggestions = json.load(f)
         
         suggestions = oldsuggestions + suggestions

         with open("data.json", "w") as f:
             json.dump(suggestions, f, indent=4)

         emoji = '✔️'

         await ctx.message.add_reaction(emoji)

     @commands.command()
     async def list(self, ctx):

         with open("data.json") as f:
             suggestions = json.load(f)

         embed = discord.Embed(colour = discord.Colour.green())
         embed.set_author(name="Suggestions")
         embed.add_field(name=(suggestions), value="line1= command, line2= description", inline=False)

         await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(Suggestion(bot))
    print('Suggestions has loaded')
