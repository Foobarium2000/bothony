import discord
import random
import asyncio
import os
from discord.ext import commands
from discord.utils import get
from gtts import gTTS 

class VoiceError(Exception):
    pass

class VoiceState:
    def __init__(self, bot: commands.Bot, ctx: commands.Context):
        self.bot = bot
        self._ctx = ctx

        self.voice = None

class Speech(commands.Cog):

     def __init__(self, client):
           self.client = client
           self.voice_states = {}

     def get_voice_state(self, ctx: commands.Context):
         state = self.voice_states.get(ctx.guild.id)
         if not state:
             state = VoiceState(self.client, ctx)
             self.voice_states[ctx.guild.id] = state

         return state
     def cog_unload(self):
         for state in self.voice_states.values():
             self.bot.loop.create_task(state.stop())

     def cog_check(self, ctx: commands.Context):
         if not ctx.guild:
             raise commands.NoPrivateMessage('This command can\'t be used in DM channels.')

         return True

     async def cog_before_invoke(self, ctx: commands.Context):
         ctx.voice_state = self.get_voice_state(ctx)

     async def cog_command_error(self, ctx: commands.Context, error: commands.CommandError):
         await ctx.send('ERROR: {}'.format(str(error)))

     @commands.command()
     async def tts(self, ctx, *, text=None):
         if not text:
             # We have nothing to speak
             await ctx.send(f"Hey {ctx.author.mention}, I need to know what to say please.")
             return

         vc = ctx.voice_client # We use it more then once, so make it an easy variable
         if not vc:
             # We are not currently in a voice channel
             await ctx.send("I need to be in a voice channel to do this, please use the connect command.")
             return

         # Lets prepare our text, and then save the audio file
         await ctx.send("NOW PROCESSING... This may take a while")
         tts = gTTS(text=text, lang="en")
         tts.save("text.mp3")

         try:
             # Lets play that mp3 file in the voice channel
             await ctx.send("PLAYING...")
             vc.play(discord.FFmpegPCMAudio('text.mp3'), after=lambda e: print(f"Finished playing: {e}"))

             # Lets set the volume to 1
             vc.source = discord.PCMVolumeTransformer(vc.source)
             vc.source.volume = 1

         # Handle the exceptions that can occur
         except discord.ClientException as e:
             await ctx.send(f"A client exception occured:\n`{e}`")
         except TypeError as e:
             await ctx.send(f"TypeError exception:\n`{e}`")
         except OpusNotLoaded as e:
             await ctx.send(f"OpusNotLoaded exception: \n`{e}`")

def setup(client):
     client.add_cog(Speech(client))
     print('Text2Speech has loaded')