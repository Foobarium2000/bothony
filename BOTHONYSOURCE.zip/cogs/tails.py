import discord
import random
import asyncio
import os
import json
from discord.ext import commands

class Tails(commands.Cog):
    
     def __init__(self, client):
           self.client = client

     @commands.command()
     async def tgt(self, ctx):
         
      embed = discord.Embed(colour = discord.Colour.green())
      file = "https://cdn.discordapp.com/attachments/450094294506799106/766796583299186738/20201016_175411.jpg"

      embed.set_author(name="Tails Gets Trolled")
      embed.set_image(url=file)
      embed.add_field(name="Tails hasn't been trolled yet", value="use a$tgt_troll to troll tails!", inline=False)

      await ctx.send(embed=embed)

     @commands.command()
     async def tgt_troll(self, ctx):

      embed = discord.Embed(colour = discord.Colour.green())
      file = "https://cdn.discordapp.com/attachments/450094294506799106/766797989766365204/345px-Tails_trolled.png"

      embed.set_author(name="Tails Gets Trolled")
      embed.set_image(url=file)
      embed.add_field(name="Tails has been trolled!", value="congrats, you troll. +1 Point", inline=False)

      await ctx.send(embed=embed)

class Points(commands.Cog):
      
     def __init__(self, client):
           self.client = client

     @commands.command()
     async def leaderboard(ctx):
       with open('tails.json', 'r') as f:
             data = json.load(f)

       top_users = {k: v for k, v in sorted(data.items(), key=lambda item: item[1], reverse=True)}

       names = ''
       for postion, user in enumerate(top_users):
             # add 1 to postion to make the index start from 1
             names += f'{postion+1} - <@!{user}> with {top_users[user]}\n'

       embed = discord.Embed(title="Leaderboard")
       embed.add_field(name="Names", value=names, inline=False)
       await ctx.send(embed=embed)



def setup(client):
     client.add_cog(Tails(client))
     print('TGT has loaded')