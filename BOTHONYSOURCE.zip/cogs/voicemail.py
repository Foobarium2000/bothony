import discord
import random
import asyncio
import os
from discord.ext import commands
from discord.utils import get
from discord.ext import tasks

class VoiceError(Exception):
    pass

class VoiceState:
    def __init__(self, bot: commands.Bot, ctx: commands.Context):
        self.bot = bot
        self._ctx = ctx

        self.voice = None

class Voicemail(commands.Cog):

     def __init__(self, client):
           self.client = client
           self.voice_states = {}

     def get_voice_state(self, ctx: commands.Context):
         state = self.voice_states.get(ctx.guild.id)
         if not state:
             state = VoiceState(self.client, ctx)
             self.voice_states[ctx.guild.id] = state

         return state
     def cog_unload(self):
         for state in self.voice_states.values():
             self.bot.loop.create_task(state.stop())

     def cog_check(self, ctx: commands.Context):
         if not ctx.guild:
             raise commands.NoPrivateMessage('This command can\'t be used in DM channels.')

         return True

     async def cog_before_invoke(self, ctx: commands.Context):
         ctx.voice_state = self.get_voice_state(ctx)

     async def cog_command_error(self, ctx: commands.Context, error: commands.CommandError):
         await ctx.send('ERROR: {}'.format(str(error)))

     
     @commands.command()
     async def voice(self, ctx: commands.context, *, channel: discord.VoiceChannel = None):
         voice = get(self.client.voice_clients, guild=ctx.guild)

         if not channel and not ctx.author.voice:
            raise VoiceError('You are neither connected to a voice channel nor specified a channel to join.')

         destination = channel or ctx.author.voice.channel
         if ctx.voice_state.voice:
             await ctx.voice_state.voice.move_to(destination)
             return
         ctx.voice_state.voice = await destination.connect()
         #await ctx.message.delete()

         voice = get(self.client.voice_clients, guild=ctx.guild)
         
         print("STARTING INDICATOR...")
         voice.play(discord.FFmpegPCMAudio("notify.mp3"))
         voice.source = discord.PCMVolumeTransformer(voice.source)
         voice.source.volume = 0.07
         while voice.is_playing():
             await asyncio.sleep(1)
         print("PLAYING RECORDED MESSAGE...")
         voice.play(discord.FFmpegPCMAudio("recording.mp3"))
         voice.source = discord.PCMVolumeTransformer(voice.source)
         voice.source.volume = 0.07
         while voice.is_playing():
             await asyncio.sleep(1)
         ctx.voice_state.voice = await voice.disconnect()
         voice.stop()
         print ("RECORDING FINISHED")
        
         
def setup(bot):
    bot.add_cog(Voicemail(bot))
    print('Voice Messaging has loaded')