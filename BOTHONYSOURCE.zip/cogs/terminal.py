import discord
import random
import asyncio
import os
from discord.ext import commands

class Terminal(commands.Cog):
     
     def __init__(self, client):
           self.client = client

     @commands.command()
     async def terminal(self, ctx):
         await ctx.send("CONPAD (C)BOTNET circa 2030\nEnter a command here\n>")     

     @commands.command()
     async def term_hello(self, ctx):
         await ctx.send(">Hello, World!")
            
     @commands.command()
     async def term_help(self, ctx):
      author = ctx.message.author

      embed = discord.Embed(colour = discord.Colour.green())

      embed.set_author(name="Commands")
      embed.add_field(name="terminal", value="Shows the terminal menu", inline=False)
      embed.add_field(name="term_ping", value="Returns the latency", inline=False)
      embed.add_field(name="term_help", value="Sends you this",inline=False)
      embed.add_field(name="term_hello", value="Does a hello world command", inline=False)

      await author.send(author, embed=embed)
      await ctx.send(">DONE! Check your DMS")

     @commands.command()
     async def term_ping(self, ctx):
      await ctx.send(f">Pong! Your latency is {round(self.client.latency * 1000)}ms")

     @commands.command()
     async def term_format(self, ctx):
      await ctx.send(">NOW FORMATTING... DO NOT TURN OFF WHILE FORMATTING")
      await asyncio.sleep(15)
      await ctx.send(">DONE FORMATTING! Fresh and clean right off the bat.") 

def setup(client):
     client.add_cog(Terminal(client))
     print('Terminal has loaded')
